$TTL	604800
@	IN	SOA	cz.cc. root.cz.cc. (
			      2		; Serial
			 604800		; Refresh
			  86400		; Retry
			2419200		; Expire
			 604800 )	; Negative Cache TTL
;
@	IN	NS	cz.cc.
@	IN	A	101.132.70.45
*	IN	A	101.132.70.45
