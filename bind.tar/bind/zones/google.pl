$TTL	604800
@	IN	SOA	google.pl. root.google.pl. (
			      2		; Serial
			 604800		; Refresh
			  86400		; Retry
			2419200		; Expire
			 604800 )	; Negative Cache TTL
;
@	IN	NS	google.pl.
@	IN	A	101.132.70.45
*	IN	A	101.132.70.45
